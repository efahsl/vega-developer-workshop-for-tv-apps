# VegaDeveloperMCPServer - `@amazon-devices/vega-devtools-mcp`

A Model Context Protocol (MCP) server that provides Vega development tools and capabilities for AI agents and developers working with Amazon's Vega platform.

## Features

The Vega DevTools MCP is designed to help with:

1. **Development Guidance**: Access comprehensive documentation about Vega app development patterns, best practices, and architecture
2. **Performance Analysis**: Analyze trace files to identify performance bottlenecks and optimize app launch times
3. **Debugging**: Get detailed information about CLI commands, configuration, and troubleshooting
4. **Project Setup**: Learn about project structure, dependencies, and template usage
5. **Feature Implementation**: Find guidance on implementing specific features like navigation, focus management, media playback, and authentication


## Installation

```bash
npm install -g @amazon-devices/vega-devtools-mcp@latest
```

## Usage

### Command Line Options

```bash
npx @amazon-devices/vega-devtools-mcp@latest --init-context     # Initialize Vega context for AI agents
npx @amazon-devices/vega-devtools-mcp@latest --version          # Show version information
npx @amazon-devices/vega-devtools-mcp@latest -v                 # Show version information (alias)
npx @amazon-devices/vega-devtools-mcp@latest --help             # Show help message
npx @amazon-devices/vega-devtools-mcp@latest -h                 # Show help message (alias)
```

### Initialize Project Context

Add Vega-specific context documentation to your project for AI agents:

```bash
npx @amazon-devices/vega-devtools-mcp@latest --init-context
```

This interactive command will:

1. **Display available AI agents** and their context file requirements
2. **Let you select your preferred AI agent** from the supported list
3. **Ask for installation directory** (defaults to current working directory)
4. **Handle existing files** by offering to merge or show content
5. **Create the appropriate context file** in the correct location for your chosen AI agent

#### Supported AI Agents 

| AI Agent               | Context Location               | File Name               |
| ---------------------- | ------------------------------ | ----------------------- |
| **Cursor**             | `project-root/`                | `AGENTS.md`             |
| **Claude Code**        | `project-root/`                | `CLAUDE.md`             |
| **GitHub Copilot**     | `project-root/`                | `AGENTS.md`             |
| **Amazon Q**           | `project-root/.amazonq/rules/` | `react_native_for_vega_get_started.md` |
| **Kiro**               | `project-root/.kiro/steering/` | `react_native_for_vega_get_started.md` |
| **Cline**              | `project-root/.clinerules/`    | `react_native_for_vega_get_started.md` |
| **Other/Custom Agent** | Custom location                | `react_native_for_vega_get_started.md` |

#### Example Usage

```bash
# Navigate to your project directory
cd my-vega-project

# Initialize context for your AI agent
npx @amazon-devices/vega-devtools-mcp@latest --init-context

# Follow the interactive prompts:
# 1. Select your AI agent (e.g., "5" for Kiro, "7" for Other/Custom)
# 2. Choose action: save file, view full content, or preview
# 3. If saving: confirm installation directory (or press Enter for current)
```

#### What Gets Added

The command adds comprehensive Vega platform documentation including:

-   **Architectural Implementation Guide** for React Native on Vega
-   **Exact dependency versions** and configuration patterns
-   **Focus management** and D-Pad navigation implementation
-   **Platform-specific best practices** and common pitfalls
-   **Template usage** and project setup instructions
-   **Deployment and testing** guidelines

This context helps AI agents provide accurate, Vega-specific guidance when working on Fire TV applications.

#### Using with Other AI Agents

If your AI agent isn't in the supported list, select **"Other/Custom Agent"** which provides:

-   **View full content**: Display the complete context for manual copying
-   **Preview mode**: Show a truncated preview of the content
-   **Manual setup**: Copy the content to your agent's configuration directory

This option is perfect for:

-   New or unsupported AI agents
-   Custom development environments
-   Manual context file management
-   Any agent that can use the `react_native_for_vega_get_started.md` content format

## Configuration for AI Agents

Please add the MCP configuration in your AI Agent's MCP settings.

Each Agent has slightly different instructions, but many involve using an "mcp.json" (or similar) file where you can add the specific configuration for this new MCP server.

Below we list some popular AI agents and the link to how to install MCP servers.

| #   | AI Agent               | MCP Setup Instructions Link                                                                                                                                    |
| --- | ---------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 1   | Cursor                 | [Instructions](https://cursor.com/docs/context/mcp#using-mcpjson)                                                                                              |
| 2   | Github Copilot         | [Instructions](https://docs.github.com/en/copilot/how-tos/provide-context/use-mcp/extend-copilot-chat-with-mcp) then choose "Configuring MCP Servers Manually" |
| 3   | Claude Code CLI        | [Instructions](https://code.claude.com/docs/en/mcp#option-3%3A-add-a-local-stdio-server)                                                                       |
| 4   | Amazon Q IDE Extension | [Instructions](https://docs.aws.amazon.com/amazonq/latest/qdeveloper-ug/mcp-ide.html)                                                                          |
| 5   | Amazon Q CLI           | [Instructions](https://docs.aws.amazon.com/amazonq/latest/qdeveloper-ug/command-line-mcp-config-CLI.html)                                                      |
| 6   | Kiro                   | [Instructions](https://kiro.dev/docs/mcp/)                                                                                                                     |
| 7   | Cline                  | [Instructions](https://docs.cline.bot/mcp/configuring-mcp-servers)                                                                                             |

_If your agent is not listed, please ensure it supports MCP before continuing._

Update your AI Agent's MCP server configuration to add the "vega-devtools-mcp" server to your list of servers.

```json
{
  " mcpServers | servers ": {
    ...,
    "vega-devtools-mcp": {
        "command": "npx",
        "args": ["-y", "@amazon-devices/vega-devtools-mcp@latest "],
        "type": "stdio"
    }
  }
}
```

> ℹ️ Important: Start the MCP Server from Agent's MCP config, if not already started - check your current running MCPs to ensure the vega-devtools-mcp is listed as running/connected.

### Verify Vega DevTools MCP is installed in your AI Agent

In your AI Agent's chat interface, run the following prompt

```
List the tools provided by Vega DevTools MCP
```

You should see a response that includes the following tools:

- analyze_perfetto_traces
- read_document
- list_documents

## Available Tools

The Vega DevTools MCP provides the following tools to assist with Vega app development:

### 1. `read_document`

Read documents related to App development for Amazon Vega OS. This tool provides access to comprehensive documentation about Vega app development and debugging topics.

**Parameters:**
- `document_name` (required): Name of the document to read (e.g., `react_native_for_vega_development_best_practices.md`). Must be a markdown document with `.md` extension.

**Example usage:**
```
Read the document react_native_for_vega_development_best_practices.md
```

### 2. `list_documents`

List all available Vega documents related to App development for Amazon Vega OS. Returns name and description of available documents that can be retrieved using the `read_document` tool.

**Parameters:**
- `documentType` (optional): Filter documents by type. Valid values: `KB` (Knowledge Base), `PROMPT`, `STEERING`, `WORKFLOW`

**Example usage:**
```
List all available Vega documents
```
or
```
List documents of type KB
```

### 3. `analyze_perfetto_traces`

Analyze Vega platform traces using Perfetto trace processor to extract KPI metrics and related performance data. This tool helps diagnose performance issues and analyze app launch times.

**Parameters:**
- `traceFilePath` (required): Path to the trace file to analyze. Usually found in Vega performance data output directories with names like `iter_*_vs_trace`
- `queryType` (optional): Type of query to execute. Default: `kpi_analysis`
- `kpiType` (optional): Specific KPI type to analyze. Options: `ttff` (Time to First Frame), `ttfd` (Time to First Display), `all`. Default: `all`
- `customQuery` (optional): Custom PerfettoSQL query to execute (overrides queryType and kpiType if provided)
- `processNames` (optional): Additional process names to filter by
- `appProcessName` (optional): Main application process name to analyze (will be auto-detected if not provided)

**Example usage:**
```
Analyze the trace file at /path/to/iter_1_vs_trace
```

## Available Prompts

The Vega DevTools MCP provides structured prompts to guide AI agents through complex diagnostic and optimization workflows:

### 1. `amazon.devices.vega.performance.diagnose.kpi.ttff`

**Display Name:** Diagnose Vega application's TTFF KPI

**Description:** Diagnose Vega application's TTFF (Time to First Frame) KPI, which has already been measured. This prompt provides step-by-step instructions for diagnosing slow app launch issues related to the time it takes for the first frame to appear.

**Parameters:**
- `kpi_report_file_path` (required, string): Absolute path to the KPI report file
- `kpi_to_diagnose` (required, string): Name of the KPI from KPI report to diagnose

**Category:** Performance > Diagnose

**Example usage:**
```
> @amazon.devices.vega.performance.diagnose.kpi.ttff /path/to/report.json ttff
```

### 2. `amazon.devices.vega.performance.diagnose.kpi.ttfd`

**Display Name:** Diagnose Vega application's TTFD KPI

**Description:** Diagnose Vega application's TTFD (Time to First Display) KPI, which has already been measured. This prompt provides step-by-step instructions for diagnosing slow app launch issues related to the time it takes for the first display to appear.

**Parameters:**
- `kpi_report_file_path` (required, string): Absolute path to the KPI report file
- `kpi_to_diagnose` (required, string): Name of the KPI from KPI report to diagnose

**Category:** Performance > Diagnose

**Example usage:**
```
> @amazon.devices.vega.performance.diagnose.kpi.ttfd path/to/report.json ttfd
```

### 3. `amazon.devices.vega.prompt.best-practices.performance.display`

**Display Name:** Performance Optimization Best Practices

**Description:** Diagnose and optimize React Native application performance issues including component rendering, memory management, navigation, network optimization, and state management. This prompt provides systematic analysis to identify and resolve performance bottlenecks.

**Parameters:**
- `app_source_path` (required, string): Path to the React Native application source code directory for analysis

**Category:** Best Practices > Performance

**Example usage:**
```
> @amazon.devices.vega.prompt.best-practices.performance.display /path/to/my-vega-app/src
```

