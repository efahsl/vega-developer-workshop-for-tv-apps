#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOCAL_CLI_JS="$SCRIPT_DIR/cli.js"

# Detect OS
OS="$(uname -s)"
case "$OS" in
  Darwin|Linux) ;;
  *) echo "❌ Unsupported OS: $OS"; exit 1 ;;
esac

if [ ! -f "$LOCAL_CLI_JS" ]; then
  echo "❌ Could not find the patch file. Make sure cli.js is in the same directory as this script."
  exit 1
fi

if ! command -v vega &>/dev/null; then
  echo "❌ vega CLI not found. Please follow the workshop instructions to install it."
  exit 1
fi

# Parse SDK info
SDK_JSON=$(vega sdk ls --json 2>/dev/null)
ACTIVE_SEMVER=$(echo "$SDK_JSON" | python3 -c "import sys,json; print(json.load(sys.stdin).get('activeSemver',''))" 2>/dev/null || true)

# Find highest 0.23 SDK installed
read -r HIGHEST_23_SEMVER HIGHEST_23_PATH < <(echo "$SDK_JSON" | python3 -c "
import sys, json
data = json.load(sys.stdin)
best = None
for v in data.get('versions', []):
    parts = v['semver'].split('.')
    if len(parts) >= 2 and parts[0] == '0' and parts[1] == '23':
        if best is None or [int(x) for x in v['semver'].split('.')] > [int(x) for x in best['semver'].split('.')]:
            best = v
print(f\"{best['semver']} {best['sdkPath']}\" if best else ' ')
" 2>/dev/null || echo " ")

# Helper to compare semver: returns 0 if $1 >= $2
semver_gte() {
  python3 -c "
a = [int(x) for x in '$1'.split('.')]
b = [int(x) for x in '$2'.split('.')]
exit(0 if a >= b else 1)
"
}

is_023() {
  python3 -c "
v = '$1'.split('.')
exit(0 if len(v) >= 2 and v[0] == '0' and v[1] == '23' else 1)
"
}

# If active SDK is not 0.23, try to switch to highest 0.23
if ! is_023 "$ACTIVE_SEMVER"; then
  if [ -z "$HIGHEST_23_SEMVER" ]; then
    echo "❌ No 0.23 SDK installed. Please follow the workshop instructions to install the workshop SDK."
    exit 1
  fi
  echo "⚠️  Active SDK ($ACTIVE_SEMVER) is not 0.23. Switching to $HIGHEST_23_SEMVER..."
  vega sdk use "$HIGHEST_23_SEMVER"
  ACTIVE_SEMVER="$HIGHEST_23_SEMVER"
  SDK_PATH="$HIGHEST_23_PATH"
else
  SDK_PATH=$(echo "$SDK_JSON" | python3 -c "
import sys, json
data = json.load(sys.stdin)
for v in data.get('versions', []):
    if v['semver'] == '${ACTIVE_SEMVER}':
        print(v['sdkPath'])
        break
" 2>/dev/null)
fi

echo "📦 Active SDK: $ACTIVE_SEMVER"

# Check if patch is needed
if semver_gte "$ACTIVE_SEMVER" "0.23.6300"; then
  echo "✅ Your SDK is up to date. No patch needed!"
  exit 0
fi

# Patch needed
TARGET_CLI_JS=$(find "$SDK_PATH/packages/KeplerCLI" -path "*/kepler/dist/cli.js" -type f 2>/dev/null | head -1)

if [ -z "$TARGET_CLI_JS" ]; then
  echo "❌ Could not locate cli.js in the SDK. Is this the correct SDK path?"
  exit 1
fi

mv "$TARGET_CLI_JS" "$TARGET_CLI_JS.backup"
cp "$LOCAL_CLI_JS" "$TARGET_CLI_JS"
echo ""
echo "✅ Workshop patch installed successfully!"
